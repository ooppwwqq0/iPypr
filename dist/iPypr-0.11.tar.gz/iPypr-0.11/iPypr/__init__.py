__author__ = 'sha256'
from ._iPypr import pypr as pypr

__all__ = ['pypr',]
