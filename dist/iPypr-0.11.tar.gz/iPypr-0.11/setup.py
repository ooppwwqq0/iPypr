#!/usr/bin/env python
# -*- coding: utf-8 -*-

# setup.py
#from distutils.core import setup
from setuptools import setup, find_packages

setup(
    name="iPypr",
    version="0.11",
    author="Casstiel",
    author_email="emo_ooppwwqq0@163.com",
    description="Like PHP print_r for Python",
    url="http://c.isme.pub/Pypr",
    packages= find_packages(),
)
